<?php

namespace App\Http\Controllers\API\Handle;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ResponseController extends Controller
{
    //
}
